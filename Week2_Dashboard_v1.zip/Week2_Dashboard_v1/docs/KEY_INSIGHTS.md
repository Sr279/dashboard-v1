# Key insights (paste into a text box on the dashboard)

1. **Analytics** has the most documents (119 of 300, 40%).
2. **Programming** documents are downloaded most on average (1005 downloads per document, library average 970). The gap between categories is small (10% of the average), so do not over-interpret it.
3. Most documents are in **English** (77%); Hindi is the smallest known language group (18 documents).
4. The most documents were created in **2023** (79 documents).
5. 70% of documents with a known status are reviewed, so about 30% still need a review.

Edit these in your own words after you see your dashboard. Download values for some rows are median estimates from the cleaning step.
