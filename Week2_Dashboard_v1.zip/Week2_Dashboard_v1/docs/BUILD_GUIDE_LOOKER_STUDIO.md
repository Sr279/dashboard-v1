# Build guide — Looker Studio (recommended: free, works in the Chrome browser, nothing to install)

Time needed: about 60-90 minutes. Menu names can change slightly; use the search box in Looker Studio if you cannot find something.

## Part 1 — Put the data in Google Sheets
1. Open https://sheets.google.com and start a **blank spreadsheet**. Name it `pdf_library_dashboard`.
2. **File -> Import -> Upload** and choose `data/pdf_library_dashboard.csv`.
3. Import location: **Replace spreadsheet**, separator type: **Comma** (or Detect automatically). Click **Import data**.
4. Check: 300 rows plus the header, 16 columns. Empty cells in `created_year` and `reviewed_flag` are normal (unknown values).

## Part 2 — Create the report
1. Go to https://lookerstudio.google.com and sign in with the same Google account.
2. **Create -> Report -> Google Sheets** connector, choose `pdf_library_dashboard`, then **Add -> Add to report**.
3. Rename the report (top-left) to **PDF Library Dashboard v1**.
4. **Theme and layout -> Layout**: set a custom canvas of 1280 x 720 (16:9). Hide the header if you like.

## Part 3 — Fix the field types and add the metrics
Open **Resource -> Manage added data sources -> Edit**.
1. `doc_id` -> Number (we only count it). `created_year_label` -> **Text**. `created_year` -> Number with aggregation **None**.
2. `created_date` can stay as text (we do not need it).
3. `reviewed_flag` -> Number, aggregation **Average**, display as **Percent**.
4. Click **Add a field** and create these (names exactly as shown):

| Field name | Formula |
|---|---|
| Total Downloads | `SUM(downloads)` |
| Avg Downloads per Doc | `AVG(downloads)` |
| Avg Pages | `AVG(page_count)` |
| Reviewed % | `AVG(reviewed_flag)` (set type Percent) |

`Record Count` (built in) is the number of documents, because each row is one document. Click **Done**.

## Part 4 — Build the visuals (**Add a chart** menu)
Add the four KPI cards first, then the charts. Use **Style** tab for colours (see `DASHBOARD_DESIGN.md`).

| Visual | Type | Dimension | Metric | Sort / extra |
|---|---|---|---|---|
| KPI 1 | Scorecard | - | Record Count (rename "Total documents") | - |
| KPI 2 | Scorecard | - | Total Downloads | - |
| KPI 3 | Scorecard | - | Avg Pages | 1 decimal |
| KPI 4 | Scorecard | - | Reviewed % | filter: exclude `reviewed_label` = Unknown |
| 1 | Bar chart (horizontal) | category | Record Count | sort: Record Count descending |
| 2 | Column chart | category | Avg Downloads per Doc | sort: metric descending |
| 3 | Line chart | created_year_label | Record Count | sort: created_year_label ascending; **chart filter: exclude created_year_label = Unknown** |
| 4 | Donut | language | Record Count | - |
| 5 | Bar chart (horizontal) | title | Total Downloads | sort descending, **rows per page: 10** |
| 6 | Donut | reviewed_label | Record Count | chart filter: exclude `reviewed_label` = Unknown |

How to add a chart filter: select the chart -> **Setup** tab -> **Add a filter** -> **Create a filter** -> *Exclude* -> field -> *Equal to (=)* -> `Unknown` -> Save.

## Part 5 — Add the filters (controls)
**Add a control -> Drop-down list**, three times: `category`, `language`, `created_year_label`. Place them top right. They filter all charts on the page.

## Part 6 — Titles, insights and polish
1. Add a **Text** box for the title "PDF Library Dashboard v1" and a smaller line "Source: cleaned data, 300 documents".
2. Add a text box "Key insights" and paste the lines from `docs/KEY_INSIGHTS.md` (edit them in your own words).
3. Give every chart a title (**Style -> Chart title**) that is a question or a clear label.
4. Align and space the visuals (select several -> right-click -> Align / Distribute).

## Part 7 — Test it (important)
Open **View** mode and follow `docs/TEST_CHECKLIST.md`. Every number must match `docs/EXPECTED_VALUES.md`.

## Part 8 — Share and export
1. **Share -> Manage access -> Anyone with the link: Viewer**, then **Get report link** and copy it.
2. **File -> Download -> PDF** (saves the dashboard as a PDF).
3. Take a full-screen screenshot and save it as `images/my_dashboard_screenshot.png`.
4. Submit: report link + PDF + screenshot + short note (see `docs/SUBMISSION_NOTE.md`).
