# Expected values — use these to TEST your dashboard

If your dashboard shows different numbers, something is wrong (wrong file, wrong field type, wrong aggregation).

## Data profile (look at the data first)
- Rows: **300**, columns in the dashboard file: **16**
- Missing values: `created_date` / `created_year` = 32, `reviewed` unknown = 15; no other missing values.
- Note: during cleaning, missing numbers were filled with the median (see the cleaning report), so `downloads` for those rows is an estimate.

## KPI cards (no filters)
| KPI | Expected value |
|---|---|
| Total documents | 300 |
| Total downloads | 291,107 |
| Average downloads per document | 970.4 |
| Average pages per document | 62.0 |
| Reviewed % (of documents with a known status) | 70.2% |

## Chart 1 and 2 — by category
| category | documents | total_downloads | avg_downloads | avg_pages |
|---|---|---|---|---|
| Analytics | 119 | 116979 | 983.0 | 62.3 |
| Database | 86 | 79589 | 925.5 | 65.3 |
| Programming | 85 | 85453 | 1005.3 | 59.5 |
| Uncategorised | 10 | 9086 | 908.6 | 50.8 |

## Chart 3 — documents by year (Unknown excluded)
| year | documents |
|---|---|
| 2022 | 59 |
| 2023 | 79 |
| 2024 | 76 |
| 2025 | 54 |

## Chart 4 — documents by language
| language | documents |
|---|---|
| English | 231 |
| Telugu | 39 |
| Hindi | 18 |
| Unknown | 12 |

## Chart 5 — Top 10 documents by downloads
| # | title | category | downloads |
|---|---|---|---|
| 1 | Kaggle Report Vol 20 | Analytics | 1986 |
| 2 | Testing with pytest Vol 25 | Programming | 1983 |
| 3 | Data Cleaning Handbook Vol 24 | Analytics | 1975 |
| 4 | Pandas Notes Vol 24 | Programming | 1972 |
| 5 | Kaggle Report Vol 3 | Analytics | 1969 |
| 6 | Statistics Primer Vol 3 | Analytics | 1964 |
| 7 | Data Cleaning Handbook Vol 14 | Analytics | 1919 |
| 8 | Statistics Primer Vol 1 | Analytics | 1918 |
| 9 | Python Guide Vol 14 | Programming | 1906 |
| 10 | PostgreSQL Guide Vol 4 | Database | 1905 |

## Chart 6 — reviewed status (filter out "Unknown" so it matches the Reviewed % card)
| status | documents |
|---|---|
| Reviewed | 200 |
| Not reviewed | 85 |
| Unknown | 15 |

Reviewed % card = 200 / (200 + 85) = 70.2%. The 15 documents with unknown status are left out.

## Slicer tests (click a filter, the numbers must change like this)
| Filter | Total documents | Total downloads |
|---|---|---|
| Category = Analytics | 119 | 116,979 |
| Language = Telugu | 39 | 38,051 |
| Category = Analytics and Language = Telugu | 13 | 13,751 |
