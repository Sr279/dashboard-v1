# Build guide — Power BI Desktop (Windows only)

Power BI Desktop does **not** run on Chromebook, Mac or Linux. If you are not on Windows, use `BUILD_GUIDE_LOOKER_STUDIO.md` instead. Download from the Microsoft Store (free).

## Part 1 — Load the data
1. Open Power BI Desktop -> **Home -> Get data -> Text/CSV** (or **Excel workbook** for the `.xlsx`).
2. Choose `data/pdf_library_dashboard.csv` -> **Transform Data**.
3. In Power Query check the types: `doc_id`, `page_count`, `size_kb`, `downloads`, `reviewed_flag`, `size_mb` = number; `created_year_label` = **Text**; `created_date` = text (or Date). Look at the data: 300 rows, 16 columns.
4. **Close & Apply**.

## Part 2 — Add the measures
**Modeling -> New measure** for each line in `powerbi/measures.dax`. Select `Reviewed %` and set **Format = Percentage**.

## Part 3 — Build the visuals (Visualizations pane)
| Visual | Type | Fields |
|---|---|---|
| KPI 1-4 | Card | Total Documents; Total Downloads; Avg Pages; Reviewed % |
| 1 | Clustered bar | Y-axis: category; X-axis: Total Documents (sort descending) |
| 2 | Clustered column | X-axis: category; Y-axis: Avg Downloads per Doc (sort descending) |
| 3 | Line chart | X-axis: created_year_label; Y-axis: Total Documents; Filters pane: created_year_label **is not** Unknown |
| 4 | Donut | Legend: language; Values: Total Documents |
| 5 | Clustered bar | Y-axis: title; X-axis: Total Downloads; Filters pane -> title -> **Top N = 10 by Total Downloads** |
| 6 | Donut | Legend: reviewed_label; Values: Total Documents; Filters pane: reviewed_label **is not** Unknown |

## Part 4 — Slicers and polish
1. **Slicer** visuals for `category`, `language`, `created_year_label` (Format -> Slicer settings -> Style: Dropdown).
2. **Insert -> Text box** for the title and for "Key insights" (paste from `docs/KEY_INSIGHTS.md`).
3. Rename visuals' titles to clear labels; use the colours from `DASHBOARD_DESIGN.md` (View -> Themes -> Customize current theme).
4. Align with **Format -> Align / Distribute**.

## Part 5 — Test, save, export
1. Test with `docs/TEST_CHECKLIST.md` (numbers must match `docs/EXPECTED_VALUES.md`).
2. Save as `PDF_Library_Dashboard_v1.pbix`.
3. **File -> Export -> Export to PDF**, and take a screenshot for `images/my_dashboard_screenshot.png`.
4. Submit the `.pbix`, the PDF, the screenshot and the short note.
