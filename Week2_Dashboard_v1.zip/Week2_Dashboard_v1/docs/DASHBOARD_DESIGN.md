# Dashboard design — PDF Library Dashboard v1

**What I hand in (one sentence):** a one-page dashboard (4 KPI cards, 6 charts, 3 filters) built from the cleaned PDF-library data, with a short note on what I built and learned.

**Data:** `data/pdf_library_dashboard.csv` (300 documents, made from the cleaned data).

## Layout (16:9, one page)
```
+--------------------------------------------------------------------------+
|  PDF Library Dashboard v1                     [Category v][Language v][Year v] |
+-------------+-------------+--------------+------------------+
| Documents   | Downloads   | Avg pages    | Reviewed %       |   <- 4 KPI cards
+-------------+-------------+--------------+------------------+
| 1 Documents by    | 2 Avg downloads per   | 3 Documents by year |
|   category (bar)  |   doc by category     |   (line)            |
+-------------------+-----------------------+---------------------+
| 4 Language   | 5 Top 10 documents by       | 6 Reviewed status  |
|   (donut)    |   downloads (bar)           |   (donut)          |
+--------------+-----------------------------+--------------------+
        [ Key insights text box ]  (paste from docs/KEY_INSIGHTS.md)
```
See `images/dashboard_preview.png` for a picture of this layout.

## Question each chart answers (write this down, as the tip says)
| # | Chart | Question | Fields |
|---|---|---|---|
| KPI 1 | Card | How many documents do we have? | Total Documents |
| KPI 2 | Card | How many downloads in total? | Total Downloads |
| KPI 3 | Card | How long is a typical document? | Avg Pages |
| KPI 4 | Card | How much of the library is reviewed? | Reviewed % |
| 1 | Bar | Which category has the most documents? | category, count of doc_id |
| 2 | Column | Which category is downloaded most per document? | category, Avg Downloads per Doc |
| 3 | Line | How many documents were created each year? | created_year_label (exclude Unknown), count |
| 4 | Donut | Which languages does the library cover? | language, count |
| 5 | Bar (Top 10) | Which documents are the most popular? | title, Total Downloads |
| 6 | Donut | How many documents are reviewed? | reviewed_label (exclude Unknown), count |

## Design rules (keeps it simple and professional)
- Colours: navy `#1F3A5F`, teal `#2A9D8F`, amber `#E9C46A`, coral `#E76F51`, light grey cards `#F4F6F8`.
- One font, titles 12-14 pt, KPI numbers 28-32 pt.
- Every chart has a clear title and sorted bars (largest first).
- Max 3 filters. Filters affect every chart.
- Leave empty space between visuals; align edges.
