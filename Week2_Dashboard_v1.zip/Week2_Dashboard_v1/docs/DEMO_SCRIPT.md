# Demo video script (under 5 minutes, main flow only)

| Time | What to show | What to say (own words) |
|---|---|---|
| 0:00-0:30 | Dashboard in full screen | "This is my Week 2 dashboard v1, built from the cleaned PDF-library data in Looker Studio (or Power BI)." |
| 0:30-1:15 | The 4 KPI cards | "300 documents, 291,107 downloads, about 62 pages on average, and 70% reviewed." |
| 1:15-3:15 | Charts 1-6 (about 20 seconds each) | Read the question each chart answers, then the finding. |
| 3:15-4:00 | Click the filters (Category, Language, Year) | "All charts update together. For example Category = Analytics shows 119 documents." |
| 4:00-4:30 | Key insights box | "My main insights are ..." |
| 4:30-5:00 | Close | "I learned ... Thank you." |

Practise once. Do not read every number; explain what it means.
