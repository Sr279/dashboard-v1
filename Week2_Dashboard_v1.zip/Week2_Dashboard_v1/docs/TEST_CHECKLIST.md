# Test your dashboard as a user would (step 5 of the portal instructions)

Use the numbers in `docs/EXPECTED_VALUES.md`. Tick each box.

## Numbers
- [ ] Total documents = 300
- [ ] Total downloads = 291,107
- [ ] Average pages = 62.0
- [ ] Reviewed % = 70%
- [ ] Documents by category: Analytics 119, Database 86, Programming 85, Uncategorised 10
- [ ] Documents by year: 2022 = 59, 2023 = 79, 2024 = 76, 2025 = 54 ("Unknown" is not shown)
- [ ] Language donut: English 231, Telugu 39, Hindi 18, Unknown 12
- [ ] Top 10 list starts with "Kaggle Report Vol 20" (1,986 downloads)

## Filters
- [ ] Category = Analytics -> 119 documents, 116,979 downloads
- [ ] Language = Telugu -> 39 documents, 38,051 downloads
- [ ] Both filters together -> 13 documents, 13,751 downloads
- [ ] Clearing a filter returns the numbers to the totals above

## Look and feel
- [ ] Every chart has a title and readable labels (nothing cut off)
- [ ] Visuals are aligned and do not overlap
- [ ] Works when viewed in full screen
- [ ] The report link opens in a private/incognito window (sharing is on)

## If a number is wrong
1. Is the right file loaded (300 rows)? 2. Is the field type right (text vs number)? 3. Is the metric Sum/Average/Count as in the guide? 4. Did you exclude "Unknown" only where the guide says?
