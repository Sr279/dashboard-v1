# Short note for the portal (edit in your own words)

**What I built:** A one-page dashboard in (Looker Studio / Power BI - keep the one you used) from the cleaned PDF-library data (300 documents). It has 4 KPI cards (documents, downloads, average pages, reviewed %), 6 charts that each answer one question, and 3 filters (category, language, year). I tested it against numbers calculated separately in Python and wrote a short key-insights box.

**What I learned:** (write 2-3 lines yourself: for example how to choose a chart for a question, how filters change all visuals, how to check dashboard numbers against the data.)

**Links/files:** dashboard link (Looker Studio) or `.pbix`, PDF export, screenshot, demo video link.
