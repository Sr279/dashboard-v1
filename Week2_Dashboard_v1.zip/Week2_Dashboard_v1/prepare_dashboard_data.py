"""Prepare the cleaned PDF-library data for a dashboard.
Run:  python prepare_dashboard_data.py
Input : data/pdf_library_clean.csv   (the output of the Week 2 data-cleaning project)
Output: data/pdf_library_dashboard.csv and .xlsx   (load THIS into Power BI / Looker Studio)
        docs/EXPECTED_VALUES.md   (numbers your dashboard must show - use it to test)
        docs/KEY_INSIGHTS.md      (text for the 'Key insights' box)
        images/dashboard_preview.png  (what the finished dashboard can look like)
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from pathlib import Path

for folder in ["data", "docs", "images"]:
    Path(folder).mkdir(exist_ok=True)

# ---------------------------------------------------------------- 1. look at the data first
raw = pd.read_csv("data/pdf_library_clean.csv")
print("Shape (rows, columns):", raw.shape)
print(raw.head())
print("Missing values per column:")
print(raw.isna().sum())

# ---------------------------------------------------------------- 2. make it dashboard-ready
d = raw[["doc_id", "title", "author", "category", "language", "page_count", "size_kb",
         "created_date", "created_year", "downloads", "reviewed"]].copy()
d["size_mb"] = (d["size_kb"] / 1024).round(2)
d["size_label"] = np.where(d["size_kb"] >= 1000, "Large (1 MB+)", "Small (under 1 MB)")
d["page_band"] = pd.cut(d["page_count"], bins=[0, 29, 59, 10000],
                        labels=["Short (under 30)", "Medium (30-59)", "Long (60+)"]).astype(str)
d["reviewed_label"] = d["reviewed"].map({True: "Reviewed", False: "Not reviewed"}).fillna("Unknown")
d["reviewed_flag"] = d["reviewed"].map({True: 1, False: 0})            # 1 / 0 / empty -> AVERAGE gives the % reviewed
d["created_year_label"] = d["created_year"].astype("Int64").astype(str).replace("<NA>", "Unknown")
d = d.drop(columns=["reviewed"])
d.to_csv("data/pdf_library_dashboard.csv", index=False)
d.to_excel("data/pdf_library_dashboard.xlsx", index=False, sheet_name="pdf_library_dashboard")
print("Saved dashboard data:", d.shape)

# ---------------------------------------------------------------- 3. numbers the dashboard must show
n_docs = d["doc_id"].nunique()
total_dl = int(d["downloads"].sum())
avg_pages = d["page_count"].mean()
rev_pct = 100 * d["reviewed_flag"].mean()
avg_dl = total_dl / n_docs

by_cat = d.groupby("category").agg(documents=("doc_id", "count"), total_downloads=("downloads", "sum"),
                                   avg_downloads=("downloads", "mean"), avg_pages=("page_count", "mean"))
by_cat[["avg_downloads", "avg_pages"]] = by_cat[["avg_downloads", "avg_pages"]].round(1)
by_cat = by_cat.sort_values("documents", ascending=False)
by_lang = d["language"].value_counts()
by_year = d[d["created_year_label"] != "Unknown"].groupby("created_year_label")["doc_id"].count()
by_rev = d["reviewed_label"].value_counts()
top10 = d.sort_values(["downloads", "title"], ascending=[False, True]).head(10)[["title", "category", "downloads"]]

def table(frame, index_name):
    h = [index_name] + [str(c) for c in frame.columns]
    out = ["| " + " | ".join(h) + " |", "|" + "---|" * len(h)]
    for i, r in zip(frame.index, frame.astype(object).values):
        out.append("| " + " | ".join([str(i)] + [str(v) for v in r]) + " |")
    return "\n".join(out)

filter_cat = by_cat.index[0]
fc = d[d["category"] == filter_cat]
filter_lang = "Telugu"
fl = d[d["language"] == filter_lang]

expected = f"""# Expected values — use these to TEST your dashboard

If your dashboard shows different numbers, something is wrong (wrong file, wrong field type, wrong aggregation).

## Data profile (look at the data first)
- Rows: **{raw.shape[0]}**, columns in the dashboard file: **{d.shape[1]}**
- Missing values: `created_date` / `created_year` = {int(d['created_year'].isna().sum())}, `reviewed` unknown = {int((d['reviewed_label'] == 'Unknown').sum())}; no other missing values.
- Note: during cleaning, missing numbers were filled with the median (see the cleaning report), so `downloads` for those rows is an estimate.

## KPI cards (no filters)
| KPI | Expected value |
|---|---|
| Total documents | {n_docs} |
| Total downloads | {total_dl:,} |
| Average downloads per document | {avg_dl:.1f} |
| Average pages per document | {avg_pages:.1f} |
| Reviewed % (of documents with a known status) | {rev_pct:.1f}% |

## Chart 1 and 2 — by category
{table(by_cat, "category")}

## Chart 3 — documents by year (Unknown excluded)
{table(by_year.to_frame("documents"), "year")}

## Chart 4 — documents by language
{table(by_lang.to_frame("documents"), "language")}

## Chart 5 — Top 10 documents by downloads
{table(top10.reset_index(drop=True).rename_axis("#").set_index(pd.RangeIndex(1, 11)), "#")}

## Chart 6 — reviewed status (filter out "Unknown" so it matches the Reviewed % card)
{table(by_rev.to_frame("documents"), "status")}

Reviewed % card = {int(by_rev.get("Reviewed", 0))} / ({int(by_rev.get("Reviewed", 0))} + {int(by_rev.get("Not reviewed", 0))}) = {rev_pct:.1f}%. The {int(by_rev.get("Unknown", 0))} documents with unknown status are left out.

## Slicer tests (click a filter, the numbers must change like this)
| Filter | Total documents | Total downloads |
|---|---|---|
| Category = {filter_cat} | {len(fc)} | {int(fc['downloads'].sum()):,} |
| Language = {filter_lang} | {len(fl)} | {int(fl['downloads'].sum()):,} |
| Category = {filter_cat} and Language = {filter_lang} | {len(fc[fc['language'] == filter_lang])} | {int(fc[fc['language'] == filter_lang]['downloads'].sum()):,} |
"""
Path("docs/EXPECTED_VALUES.md").write_text(expected, encoding="utf-8")

# ---------------------------------------------------------------- 4. key insights for the text box
best_dl = by_cat["avg_downloads"].idxmax()
known_lang = by_lang.drop("Unknown", errors="ignore")
spread = (by_cat["avg_downloads"].max() - by_cat["avg_downloads"].min()) / avg_dl * 100
spread_note = ("The gap between categories is small (" + f"{spread:.0f}" + "% of the average), so do not over-interpret it." if spread < 15 else "The gap between categories is large enough to act on.")
top_year = by_year.idxmax()
insights = f"""# Key insights (paste into a text box on the dashboard)

1. **{by_cat.index[0]}** has the most documents ({int(by_cat['documents'].iloc[0])} of {n_docs}, {100 * by_cat['documents'].iloc[0] / n_docs:.0f}%).
2. **{best_dl}** documents are downloaded most on average ({by_cat.loc[best_dl, 'avg_downloads']:.0f} downloads per document, library average {avg_dl:.0f}). {spread_note}
3. Most documents are in **{by_lang.index[0]}** ({100 * by_lang.iloc[0] / n_docs:.0f}%); {known_lang.index[-1]} is the smallest known language group ({int(known_lang.iloc[-1])} documents).
4. The most documents were created in **{top_year}** ({int(by_year.max())} documents).
5. {rev_pct:.0f}% of documents with a known status are reviewed, so about {100 - rev_pct:.0f}% still need a review.

Edit these in your own words after you see your dashboard. Download values for some rows are median estimates from the cleaning step.
"""
Path("docs/KEY_INSIGHTS.md").write_text(insights, encoding="utf-8")

# ---------------------------------------------------------------- 5. preview picture
NAVY, TEAL, AMBER, CORAL, GREY = "#1F3A5F", "#2A9D8F", "#E9C46A", "#E76F51", "#F4F6F8"
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
fig = plt.figure(figsize=(16, 9), facecolor="white")
fig.text(0.03, 0.955, "PDF Library Dashboard v1", fontsize=22, fontweight="bold", color=NAVY)
fig.text(0.03, 0.918, f"Source: cleaned data, {n_docs} documents", fontsize=10, color="#555")
for i, label in enumerate(["Category: All", "Language: All", "Year: All"]):
    fig.text(0.70 + i * 0.100, 0.945, label, fontsize=9, color=NAVY,
             bbox=dict(boxstyle="round,pad=0.4", facecolor=GREY, edgecolor="#bbb"))
kpis = [("Total documents", f"{n_docs}"), ("Total downloads", f"{total_dl:,}"),
        ("Avg pages / document", f"{avg_pages:.1f}"), ("Reviewed %", f"{rev_pct:.0f}%")]
for i, (lab, val) in enumerate(kpis):
    x = 0.03 + i * 0.2425
    ax = fig.add_axes([x, 0.78, 0.225, 0.095]); ax.axis("off")
    ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.0,rounding_size=0.08", fc=GREY, ec="#ddd", transform=ax.transAxes))
    ax.text(0.5, 0.60, val, ha="center", va="center", fontsize=22, fontweight="bold", color=NAVY, transform=ax.transAxes)
    ax.text(0.5, 0.18, lab, ha="center", va="center", fontsize=10, color="#555", transform=ax.transAxes)

def panel(rect, title):
    a = fig.add_axes(rect); a.set_title(title, loc="left", fontsize=11, fontweight="bold", color=NAVY); return a

a = panel([0.10, 0.46, 0.21, 0.26], "Documents by category")
c = by_cat["documents"].sort_values(); b = a.barh(c.index, c.values, color=TEAL); a.bar_label(b, padding=2)
a = panel([0.39, 0.46, 0.26, 0.26], "Average downloads per document by category")
c = by_cat["avg_downloads"].sort_values(ascending=False); b = a.bar(c.index, c.values, color=NAVY)
a.bar_label(b, labels=[f"{v:.0f}" for v in c.values], padding=2); plt.setp(a.get_xticklabels(), rotation=20, ha="right")
a = panel([0.73, 0.46, 0.24, 0.26], "Documents by year")
a.plot(by_year.index, by_year.values, marker="o", color=CORAL); a.set_ylim(0, by_year.max() * 1.25)
for x_, y_ in zip(by_year.index, by_year.values): a.annotate(str(y_), (x_, y_), textcoords="offset points", xytext=(0, 6), ha="center")
a = panel([0.02, 0.07, 0.24, 0.30], "Documents by language")
a.pie(by_lang.values, autopct=lambda p_: f"{p_:.0f}%" if p_ >= 5 else "", colors=[NAVY, TEAL, AMBER, CORAL][:len(by_lang)],
      wedgeprops=dict(width=0.45), textprops=dict(color="white", fontsize=9))
a.legend(by_lang.index, loc="center left", bbox_to_anchor=(0.95, 0.5), frameon=False, fontsize=8)
a = panel([0.42, 0.07, 0.31, 0.30], "Top 10 documents by downloads")
t = top10.iloc[::-1]; b = a.barh(t["title"], t["downloads"], color=TEAL); a.bar_label(b, padding=2); a.tick_params(axis="y", labelsize=8)
a = panel([0.76, 0.12, 0.17, 0.25], "Reviewed status (known only)")
known_rev = by_rev.drop("Unknown", errors="ignore")
a.pie(known_rev.values, autopct="%1.0f%%", colors=[TEAL, CORAL], wedgeprops=dict(width=0.45), textprops=dict(color="white", fontsize=9))
a.legend(known_rev.index, loc="upper center", bbox_to_anchor=(0.5, 0.02), ncol=2, frameon=False, fontsize=8)
fig.text(0.5, 0.012, "PREVIEW of the target layout (made with Python). Build your own version in Looker Studio or Power BI and replace this image with your screenshot.",
         ha="center", fontsize=9, color="#888")
fig.savefig("images/dashboard_preview.png", dpi=110)
plt.close(fig)
print("Done: data/pdf_library_dashboard.csv/.xlsx, docs/EXPECTED_VALUES.md, docs/KEY_INSIGHTS.md, images/dashboard_preview.png")
