# Week 2 — Dashboard v1: PDF Library Dashboard

**Task:** Build a simple dashboard in Power BI / Tableau / Looker Studio from the cleaned data (due 05/11/2026).

**What I hand in (one sentence):** a one-page dashboard with 4 KPI cards, 6 charts and 3 filters built from the cleaned PDF-library data, plus a short note on what I built and learned.

![Target layout](images/dashboard_preview.png)

> **Important — please read.** This image is a **preview** of the target layout, made with Python. The dashboard itself must be built by you in **Looker Studio** (free, works in Chrome) or **Power BI Desktop** (Windows only), using the guides in `docs/`. After you build it, take a screenshot and save it as `images/my_dashboard_screenshot.png`. Do not submit the preview image as your dashboard.

## What is in this folder
```
Week2_Dashboard_v1/
  README.md                          <- this file
  requirements.txt
  prepare_dashboard_data.py          <- makes the dashboard data, expected numbers, insights and the preview
  data/
    pdf_library_clean.csv            <- cleaned data (output of the Week 2 data-cleaning project)
    pdf_library_dashboard.csv        <- LOAD THIS into Looker Studio (via Google Sheets) or Power BI
    pdf_library_dashboard.xlsx       <- same data as an Excel file (Power BI)
  powerbi/measures.dax               <- Power BI measures (copy and paste)
  images/dashboard_preview.png       <- target layout
  docs/
    BUILD_GUIDE_LOOKER_STUDIO.md     <- step-by-step (recommended)
    BUILD_GUIDE_POWER_BI.md          <- step-by-step (Windows only)
    DASHBOARD_DESIGN.md              <- layout, colours, question each chart answers
    EXPECTED_VALUES.md               <- numbers your dashboard must show
    TEST_CHECKLIST.md                <- how to test it like a user
    KEY_INSIGHTS.md                  <- text for the "Key insights" box
    DEMO_SCRIPT.md                   <- 5-minute demo video script
    SUBMISSION_NOTE.md               <- short note for the portal
```

## Quick plan (3 small parts, as the portal suggests)
1. **Data (10 min):** look at `data/pdf_library_dashboard.csv` (300 rows, 16 columns) and read `docs/EXPECTED_VALUES.md`.
2. **Build (45-60 min):** follow `docs/BUILD_GUIDE_LOOKER_STUDIO.md` (or the Power BI guide). Get the 4 cards and 2 charts working first, then add the rest.
3. **Test and submit (20 min):** tick `docs/TEST_CHECKLIST.md`, take a screenshot, export a PDF, write your note, record the demo (`docs/DEMO_SCRIPT.md`).

## Which tool?
| Tool | Works on | Cost | Use it if |
|---|---|---|---|
| Looker Studio | Any computer with Chrome (Chromebook too) | Free | You do not have Windows - recommended |
| Power BI Desktop | Windows only | Free | You have a Windows laptop |
| Tableau Public | Windows / Mac (download) | Free | Your mentor asks for Tableau |

## The data
The dashboard uses the **cleaned** PDF-library dataset from the Week 2 data-cleaning project (300 documents). Some numbers were filled with the median during cleaning, and 32 documents have no creation year and 15 have an unknown review status. The guides show how to leave these out of the right charts. If your mentor gave you a different dataset, repeat the same steps with it: adjust the field names in the guides.

To re-create the dashboard data and the expected values: `pip install -r requirements.txt` then `python prepare_dashboard_data.py`.

## Submission checklist
- [ ] Dashboard built and every number tested (`docs/TEST_CHECKLIST.md`)
- [ ] Screenshot saved as `images/my_dashboard_screenshot.png`
- [ ] PDF export (and `.pbix` if Power BI) / shareable report link (Looker Studio)
- [ ] Short note in your own words (`docs/SUBMISSION_NOTE.md`)
- [ ] Demo video (under 5 minutes) if your mentor asks for it
- [ ] Upload in My Submissions before 05/11/2026 and check the status
